/*
 Zuñiga de Leon Bryan
 Gonzalez Nuñez Isai
 */
package back_end;

import java.util.Objects;

/**
 *
 * @author Isai
 */
public class Persona {
    protected String curp;
    protected String nombre;
    protected String apellidos;
    protected String telefono;
    protected String correo;

    public Persona() {
    }

    public Persona(String curp, String nombre, String apellidos, String telefono, String correo) {
        this.curp = curp;
        this.nombre = nombre;
        this.apellidos = apellidos;
        this.telefono = telefono;
        this.correo = correo;
    }

    public String getCurp() {
        return curp;
    }

    public void setCurp(String curp) {
        this.curp = curp;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 23 * hash + Objects.hashCode(this.curp);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Persona other = (Persona) obj;
        return Objects.equals(this.curp, other.curp);
    }

    @Override
    public String toString() {
        return "Persona{" + "curp=" + curp + ", nombre=" + nombre + ", apellidos=" + apellidos + ", telefono=" + telefono + ", correo=" + correo + '}';
    }
}
