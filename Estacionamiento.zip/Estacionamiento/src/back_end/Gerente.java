/*

 */
package back_end;

/**
 *
 * @author Isai
 */
public final class Gerente extends Persona {
   private String sucursal;
   private double gastos;
    
   public Gerente() {
    }

    public Gerente(String sucursal, double gastos, String curp, String nombre, String apellidos, String telefono, String correo) {
        super(curp, nombre, apellidos, telefono, correo);
        this.sucursal = sucursal;
        this.gastos = gastos;
    }

    public String getSucursal() {
        return sucursal;
    }

    public void setSucursal(String sucursal) {
        this.sucursal = sucursal;
    }

    public double getGastos() {
        return gastos;
    }

    public void setGastos(double gastos) {
        this.gastos = gastos;
    }

   

    @Override
    public String toString() {
        return super.toString()+ "Gerente{" + "sucursal=" + sucursal + ", gastos=" + gastos + '}';
    }
    
}
