/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package back_end;


public final class Valetp extends Persona {
    private String areaTrabajo;
    private String turno;

    public Valetp() {
    }

    public Valetp(String areaTrabajo, String turno, String curp, String nombre, String apellidos, String telefono, String correo) {
        super(curp, nombre, apellidos, telefono, correo);
        this.areaTrabajo = areaTrabajo;
        this.turno = turno;
    }

    public String getAreaTrabajo() {
        return areaTrabajo;
    }

    public void setAreaTrabajo(String areaTrabajo) {
        this.areaTrabajo = areaTrabajo;
    }

    public String getTurno() {
        return turno;
    }

    public void setTurno(String turno) {
        this.turno = turno;
    }

    @Override
    public String toString() {
        return super.toString()+"Valetp{" + "areaTrabajo=" + areaTrabajo + ", turno=" + turno + '}';
    }
    
}
