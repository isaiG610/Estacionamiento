/*

 */
package back_end;

/**
 *
 * @author Isai
 */
public final class LavaAutos extends Persona {
   private String propinas;
   private String autosL;

    public LavaAutos() {
    }

    public LavaAutos(String propinas, String autosL, String curp, String nombre, String apellidos, String telefono, String correo) {
        super(curp, nombre, apellidos, telefono, correo);
        this.propinas = propinas;
        this.autosL = autosL;
    }

    public String getPropinas() {
        return propinas;
    }

    public void setPropinas(String propinas) {
        this.propinas = propinas;
    }

    public String getAutosL() {
        return autosL;
    }

    public void setAutosL(String autosL) {
        this.autosL = autosL;
    }

    @Override
    public String toString() {
        return super.toString()+ "LavaAutos{" + "propinas=" + propinas + ", autosL=" + autosL + '}';
    }
    
}
