/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package back_end;

/**
 *
 * @author Isai
 */
public final class PersonalL extends Persona {
    private String sueldo;
   private String nivelL;

    public PersonalL() {
    }

    public PersonalL(String sueldo, String nivelL, String curp, String nombre, String apellidos, String telefono, String correo) {
        super(curp, nombre, apellidos, telefono, correo);
        this.sueldo = sueldo;
        this.nivelL = nivelL;
    }

    public String getSueldo() {
        return sueldo;
    }

    public void setSueldo(String sueldo) {
        this.sueldo = sueldo;
    }

    public String getNivelL() {
        return nivelL;
    }

    public void setNivelL(String nivelL) {
        this.nivelL = nivelL;
    }

    @Override
    public String toString() {
        return super.toString()+ "PersonalL{" + "sueldo=" + sueldo + ", nivelL=" + nivelL + '}';
    }
    
}
