/*

 */
package back_end;



public final class Cliente extends Persona {
 private String metodoPago;
 private String horaEntrada;
 private String horaSalida;
  public Cliente() {
    }

    public Cliente(String metodoPago, String horaEntrada, String horaSalida, String curp, String nombre, String apellidos, String telefono, String correo) {
        super(curp, nombre, apellidos, telefono, correo);
        this.metodoPago = metodoPago;
        this.horaEntrada = horaEntrada;
        this.horaSalida = horaSalida;
    }

    public String getMetodoPago() {
        return metodoPago;
    }

    public void setMetodoPago(String metodoPago) {
        this.metodoPago = metodoPago;
    }

    public String getHoraEntrada() {
        return horaEntrada;
    }

    public void setHoraEntrada(String horaEntrada) {
        this.horaEntrada = horaEntrada;
    }

    public String getHoraSalida() {
        return horaSalida;
    }

    public void setHoraSalida(String horaSalida) {
        this.horaSalida = horaSalida;
    }

    @Override
    public String toString() {
        return super.toString()+"Cliente{" + "metodoPago=" + metodoPago + ", horaEntrada=" + horaEntrada + ", horaSalida=" + horaSalida + '}';
    }
  
}
