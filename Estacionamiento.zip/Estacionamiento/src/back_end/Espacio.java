/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package back_end;

import java.util.Objects;


public final class Espacio {
  private String numeroL;
 private  String estado;
  private String especial;

    public Espacio() {
    }

    public Espacio(String numeroL, String estado, String especial) {
        this.numeroL = numeroL;
        this.estado = estado;
        this.especial = especial;
    }

    public String getNumeroL() {
        return numeroL;
    }

    public void setNumeroL(String numeroL) {
        this.numeroL = numeroL;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public String getEspecial() {
        return especial;
    }

    public void setEspecial(String especial) {
        this.especial = especial;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 31 * hash + Objects.hashCode(this.numeroL);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Espacio other = (Espacio) obj;
        return Objects.equals(this.numeroL, other.numeroL);
    }

    @Override
    public String toString() {
        return "Espacio{" + "numeroL=" + numeroL + ", estado=" + estado + ", especial=" + especial + '}';
    }
  
}
