/*

 */
package back_end;

import java.util.Objects;


public class Estacionamiento {
 private String codigo;
  private String maximoPlazas;
  private String espaciosDis;
  private String niveles;

    public Estacionamiento() {
    }

    public Estacionamiento(String maximoPlazas, String espaciosDis, String niveles) {
        this.maximoPlazas = maximoPlazas;
        this.espaciosDis = espaciosDis;
        this.niveles = niveles;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getMaximoPlazas() {
        return maximoPlazas;
    }

    public void setMaximoPlazas(String maximoPlazas) {
        this.maximoPlazas = maximoPlazas;
    }

    public String getEspaciosDis() {
        return espaciosDis;
    }

    public void setEspaciosDis(String espaciosDis) {
        this.espaciosDis = espaciosDis;
    }

    public String getNiveles() {
        return niveles;
    }

    public void setNiveles(String niveles) {
        this.niveles = niveles;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 37 * hash + Objects.hashCode(this.codigo);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Estacionamiento other = (Estacionamiento) obj;
        return Objects.equals(this.codigo, other.codigo);
    }

    @Override
    public String toString() {
        return "Estacionamiento{" + "codigo=" + codigo + ", maximoPlazas=" + maximoPlazas + ", espaciosDis=" + espaciosDis + ", niveles=" + niveles + '}';
    }
  
}
