/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package back_end;


public final class Cajero extends Persona {
   private String fondoInicial;
   private String corteF;
   private String turnoC;
   private String cantidadTickets;
    

    public Cajero() {
    }

    public Cajero(String corteF, String turnoC, String curp, String nombre, String apellidos, String telefono, String correo) {
        super(curp, nombre, apellidos, telefono, correo);
        this.corteF = corteF;
        this.turnoC = turnoC;
    }

    public String getCorteF() {
        return corteF;
    }

    public void setCorteF(String corteF) {
        this.corteF = corteF;
    }

    public String getTurnoC() {
        return turnoC;
    }

    public void setTurnoC(String turnoC) {
        this.turnoC = turnoC;
    }

    public String getCantidadTickets() {
        return cantidadTickets;
    }

    public void setCantidadTickets(String cantidadTickets) {
        this.cantidadTickets = cantidadTickets;
    }

    public String getFondoInicial() {
        return fondoInicial;
    }

    public void setFondoInicial(String fondoInicial) {
        this.fondoInicial = fondoInicial;
    }

    @Override
    public String toString() {
        return super.toString()+"Cajero{" + "corteF=" + corteF + ", turnoC=" + turnoC + ", cantidadTickets=" + cantidadTickets + ", fondoInicial=" + fondoInicial + '}';
    }
    
}
