/*
 
 */
package back_end;

import java.util.Objects;

public class Vehiculo {
   private String placasV;
   private String marcaV;
   private String modeloV;

    public Vehiculo() {
    }

    public Vehiculo(String placasV, String marcaV, String modeloV) {
        this.placasV = placasV;
        this.marcaV = marcaV;
        this.modeloV = modeloV;
    }

    public String getPlacasV() {
        return placasV;
    }

    public void setPlacasV(String placasV) {
        this.placasV = placasV;
    }

    public String getMarcaV() {
        return marcaV;
    }

    public void setMarcaV(String marcaV) {
        this.marcaV = marcaV;
    }

    public String getModeloV() {
        return modeloV;
    }

    public void setModeloV(String modeloV) {
        this.modeloV = modeloV;
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 53 * hash + Objects.hashCode(this.placasV);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Vehiculo other = (Vehiculo) obj;
        return Objects.equals(this.placasV, other.placasV);
    }

    @Override
    public String toString() {
        return "Vehiculo{" + "placasV=" + placasV + ", marcaV=" + marcaV + ", modeloV=" + modeloV + '}';
    }
   
}

