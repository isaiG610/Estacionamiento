
package front_end;

import back_end.*;
import javax.swing.JOptionPane;
import java.util.Objects;

public class GUIPersonas extends javax.swing.JFrame {
    
    private Persona per;
    private Vehiculo vehiculo;
    private Estacionamiento estacionamiento;
    private Espacio espacio;
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(GUIPersonas.class.getName());

    public GUIPersonas() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel1 = new javax.swing.JPanel();
        txtTelefono = new javax.swing.JTextField();
        txtCorreo = new javax.swing.JTextField();
        btnCrear = new javax.swing.JButton();
        btnGuardar = new javax.swing.JButton();
        btnBuscar = new javax.swing.JButton();
        btnActualizar = new javax.swing.JButton();
        btnBorrar = new javax.swing.JButton();
        btnDestruir = new javax.swing.JButton();
        lblCURP = new javax.swing.JLabel();
        lblApellidos = new javax.swing.JLabel();
        lblNombre = new javax.swing.JLabel();
        lblTelefono = new javax.swing.JLabel();
        lblCorreo = new javax.swing.JLabel();
        txtCURP = new javax.swing.JTextField();
        txtApellidos = new javax.swing.JTextField();
        txtNombre = new javax.swing.JTextField();
        jTabbedPane2 = new javax.swing.JTabbedPane();
        jPanel3 = new javax.swing.JPanel();
        lblSucursal = new javax.swing.JLabel();
        lblGastos = new javax.swing.JLabel();
        txtSucursal = new javax.swing.JTextField();
        txtGastos = new javax.swing.JTextField();
        jPanel4 = new javax.swing.JPanel();
        lblFondoIn = new javax.swing.JLabel();
        lblCorteFin = new javax.swing.JLabel();
        lblTurnoC = new javax.swing.JLabel();
        lblTickets = new javax.swing.JLabel();
        txtFondoIn = new javax.swing.JTextField();
        txtCorteFin = new javax.swing.JTextField();
        txtTurnoC = new javax.swing.JTextField();
        txtTickets = new javax.swing.JTextField();
        jPanel5 = new javax.swing.JPanel();
        lblAreaT = new javax.swing.JLabel();
        lblTurno = new javax.swing.JLabel();
        txtAreaT = new javax.swing.JTextField();
        txtTurno = new javax.swing.JTextField();
        jPanel6 = new javax.swing.JPanel();
        lblPropinas = new javax.swing.JLabel();
        lblAutosL = new javax.swing.JLabel();
        txtPropinas = new javax.swing.JTextField();
        txtAutosL = new javax.swing.JTextField();
        jPanel7 = new javax.swing.JPanel();
        lblSueldo = new javax.swing.JLabel();
        lblNivelEs = new javax.swing.JLabel();
        txtSueldo = new javax.swing.JTextField();
        txtNivelEs = new javax.swing.JTextField();
        jPanel8 = new javax.swing.JPanel();
        lblMetodo = new javax.swing.JLabel();
        lblHoraEn = new javax.swing.JLabel();
        lblHoraSa = new javax.swing.JLabel();
        txtMetodo = new javax.swing.JTextField();
        txtHoraEn = new javax.swing.JTextField();
        txtHoraSa = new javax.swing.JTextField();
        jPanel2 = new javax.swing.JPanel();
        jTabbedPane3 = new javax.swing.JTabbedPane();
        jPanel9 = new javax.swing.JPanel();
        lblPlacas = new javax.swing.JLabel();
        lblMarca = new javax.swing.JLabel();
        lblModelo = new javax.swing.JLabel();
        txtPlacas = new javax.swing.JTextField();
        txtMarca = new javax.swing.JTextField();
        txtModelo = new javax.swing.JTextField();
        btnCrearvehiculo = new javax.swing.JButton();
        btnGuardarVehiculo = new javax.swing.JButton();
        btnBuscarVehiculo = new javax.swing.JButton();
        btnActualizarVehiculo = new javax.swing.JButton();
        btnBorrarVehiculo = new javax.swing.JButton();
        btnDestruirVehiculo = new javax.swing.JButton();
        jPanel10 = new javax.swing.JPanel();
        lblCodigo = new javax.swing.JLabel();
        lblMax = new javax.swing.JLabel();
        lblEspaDis = new javax.swing.JLabel();
        lblNiveles = new javax.swing.JLabel();
        txtCodigo = new javax.swing.JTextField();
        txtMax = new javax.swing.JTextField();
        txtEspaDis = new javax.swing.JTextField();
        txtNiveles = new javax.swing.JTextField();
        btnCrearEstacionamiento = new javax.swing.JButton();
        btnGuardarEstacionamiento = new javax.swing.JButton();
        btnBuscarEstacionamiento = new javax.swing.JButton();
        btnActualizarEstacionamiento = new javax.swing.JButton();
        btnBorrarEstacionamiento = new javax.swing.JButton();
        btnDestruirEstacionamiento = new javax.swing.JButton();
        jPanel11 = new javax.swing.JPanel();
        lblNumL = new javax.swing.JLabel();
        lblEstado = new javax.swing.JLabel();
        lblEspecialidad = new javax.swing.JLabel();
        txtNumL = new javax.swing.JTextField();
        txtEstado = new javax.swing.JTextField();
        txtEspecialidad = new javax.swing.JTextField();
        btnCrearEspacio = new javax.swing.JButton();
        btnGuardarEspacio = new javax.swing.JButton();
        btnBuscarEspacio = new javax.swing.JButton();
        btnActualizarEspacio = new javax.swing.JButton();
        btnBorrarEspacio = new javax.swing.JButton();
        btnDestruirEspacio = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jTabbedPane1.setToolTipText("");
        jTabbedPane1.setName("Personas"); // NOI18N

        txtTelefono.setName("TXT_Edad"); // NOI18N

        txtCorreo.setName("TXT_Cumpleaños"); // NOI18N
        txtCorreo.addActionListener(this::txtCorreoActionPerformed);

        btnCrear.setText("Crear Objeto");
        btnCrear.addActionListener(this::btnCrearActionPerformed);

        btnGuardar.setText("Guardar datos");
        btnGuardar.setToolTipText("");
        btnGuardar.addActionListener(this::btnGuardarActionPerformed);

        btnBuscar.setText("Buscar por CURP");
        btnBuscar.addActionListener(this::btnBuscarActionPerformed);

        btnActualizar.setText("Actualizar Datos");
        btnActualizar.addActionListener(this::btnActualizarActionPerformed);

        btnBorrar.setText("Borrar datos");
        btnBorrar.addActionListener(this::btnBorrarActionPerformed);

        btnDestruir.setText("Destruir objeto");
        btnDestruir.addActionListener(this::btnDestruirActionPerformed);

        lblCURP.setText("CURP");
        lblCURP.setName("LBL_CURP"); // NOI18N

        lblApellidos.setText("Apellidos");
        lblApellidos.setName("LBL_Apellido"); // NOI18N

        lblNombre.setText("Nombre");
        lblNombre.setName("LBL_Nombre"); // NOI18N

        lblTelefono.setText("Telefono");
        lblTelefono.setName("LBL_Edad"); // NOI18N

        lblCorreo.setText("Correo");
        lblCorreo.setName("LBL_Cumpleaños"); // NOI18N

        txtCURP.setName("txtCURP"); // NOI18N
        txtCURP.addActionListener(this::txtCURPActionPerformed);

        txtApellidos.setName("TXT_Apellidos"); // NOI18N

        txtNombre.setName("TXT_Nombre"); // NOI18N

        lblSucursal.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblSucursal.setText("Sucursal:");

        lblGastos.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblGastos.setText("Gastos:");

        txtSucursal.addActionListener(this::txtSucursalActionPerformed);

        txtGastos.addActionListener(this::txtGastosActionPerformed);

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblSucursal, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblGastos, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(txtSucursal, javax.swing.GroupLayout.DEFAULT_SIZE, 124, Short.MAX_VALUE)
                    .addComponent(txtGastos))
                .addContainerGap(424, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(32, 32, 32)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblSucursal, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtSucursal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblGastos, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtGastos, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(112, Short.MAX_VALUE))
        );

        jTabbedPane2.addTab("Gerente", jPanel3);

        lblFondoIn.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblFondoIn.setText("Fondo Inicial:");

        lblCorteFin.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblCorteFin.setText("Corte Final:");

        lblTurnoC.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblTurnoC.setText("Turno cajero:");

        lblTickets.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblTickets.setText("Tickets vendidos:");

        txtFondoIn.addActionListener(this::txtFondoInActionPerformed);

        txtCorteFin.addActionListener(this::txtCorteFinActionPerformed);

        txtTurnoC.addActionListener(this::txtTurnoCActionPerformed);

        txtTickets.addActionListener(this::txtTicketsActionPerformed);

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addGroup(jPanel4Layout.createSequentialGroup()
                            .addComponent(lblFondoIn, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(txtFondoIn, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(jPanel4Layout.createSequentialGroup()
                            .addComponent(lblCorteFin, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(18, 18, 18)
                            .addComponent(txtCorteFin))
                        .addGroup(jPanel4Layout.createSequentialGroup()
                            .addComponent(lblTurnoC, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(18, 18, 18)
                            .addComponent(txtTurnoC)))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(lblTickets, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtTickets, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(421, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblFondoIn)
                    .addComponent(txtFondoIn, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblCorteFin)
                    .addComponent(txtCorteFin, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblTurnoC)
                    .addComponent(txtTurnoC, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblTickets)
                    .addComponent(txtTickets, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(66, Short.MAX_VALUE))
        );

        jTabbedPane2.addTab("Cajero", jPanel4);

        lblAreaT.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblAreaT.setText("Area Trabajo:");

        lblTurno.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblTurno.setText("Turno:");

        txtAreaT.addActionListener(this::txtAreaTActionPerformed);

        txtTurno.addActionListener(this::txtTurnoActionPerformed);

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(lblAreaT, javax.swing.GroupLayout.DEFAULT_SIZE, 86, Short.MAX_VALUE)
                    .addComponent(lblTurno, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(18, 18, 18)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(txtAreaT, javax.swing.GroupLayout.DEFAULT_SIZE, 104, Short.MAX_VALUE)
                    .addComponent(txtTurno))
                .addContainerGap(413, Short.MAX_VALUE))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblAreaT)
                    .addComponent(txtAreaT, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(25, 25, 25)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblTurno)
                    .addComponent(txtTurno, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(124, Short.MAX_VALUE))
        );

        jTabbedPane2.addTab("Valet", jPanel5);

        lblPropinas.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblPropinas.setText("Propinas:");

        lblAutosL.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblAutosL.setText("Autos Lavados:");

        txtPropinas.addActionListener(this::txtPropinasActionPerformed);

        txtAutosL.addActionListener(this::txtAutosLActionPerformed);

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(lblPropinas, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lblAutosL, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(44, 44, 44)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(txtAutosL, javax.swing.GroupLayout.DEFAULT_SIZE, 117, Short.MAX_VALUE)
                    .addComponent(txtPropinas))
                .addContainerGap(370, Short.MAX_VALUE))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGap(38, 38, 38)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblPropinas)
                    .addComponent(txtPropinas, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblAutosL)
                    .addComponent(txtAutosL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(122, Short.MAX_VALUE))
        );

        jTabbedPane2.addTab("Lava Autos", jPanel6);

        lblSueldo.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblSueldo.setText("Sueldo:");

        lblNivelEs.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblNivelEs.setText("Nivel Estacionamiento:");

        txtSueldo.addActionListener(this::txtSueldoActionPerformed);

        txtNivelEs.addActionListener(this::txtNivelEsActionPerformed);

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(lblSueldo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lblNivelEs, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(49, 49, 49)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(txtNivelEs, javax.swing.GroupLayout.DEFAULT_SIZE, 137, Short.MAX_VALUE)
                    .addComponent(txtSueldo))
                .addContainerGap(296, Short.MAX_VALUE))
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblSueldo)
                    .addComponent(txtSueldo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblNivelEs)
                    .addComponent(txtNivelEs, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(133, Short.MAX_VALUE))
        );

        jTabbedPane2.addTab("Personal de Limpieza", jPanel7);

        lblMetodo.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblMetodo.setText("Metodo de pago:");

        lblHoraEn.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblHoraEn.setText("Hora Entrada:");

        lblHoraSa.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblHoraSa.setText("Hora Salida:");

        txtMetodo.addActionListener(this::txtMetodoActionPerformed);

        txtHoraEn.addActionListener(this::txtHoraEnActionPerformed);

        txtHoraSa.addActionListener(this::txtHoraSaActionPerformed);

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(lblMetodo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(lblHoraEn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(lblHoraSa, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(txtHoraSa, javax.swing.GroupLayout.DEFAULT_SIZE, 117, Short.MAX_VALUE)
                    .addComponent(txtHoraEn)
                    .addComponent(txtMetodo))
                .addContainerGap(370, Short.MAX_VALUE))
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblMetodo)
                    .addComponent(txtMetodo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblHoraEn)
                    .addComponent(txtHoraEn, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblHoraSa)
                    .addComponent(txtHoraSa, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(96, Short.MAX_VALUE))
        );

        jTabbedPane2.addTab("Clientes", jPanel8);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(lblCURP, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lblApellidos, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lblCorreo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lblTelefono, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lblNombre, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txtCURP, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtApellidos, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtNombre, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtTelefono, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtCorreo, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(34, 34, 34)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnDestruir)
                    .addComponent(btnBorrar)
                    .addComponent(btnActualizar)
                    .addComponent(btnBuscar)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addComponent(btnCrear, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnGuardar, javax.swing.GroupLayout.Alignment.LEADING)))
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addComponent(jTabbedPane2)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblCURP, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtCURP, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnCrear))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblApellidos, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtApellidos, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnGuardar))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblNombre)
                    .addComponent(txtNombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnBuscar))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblTelefono)
                    .addComponent(txtTelefono, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnActualizar))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblCorreo)
                    .addComponent(txtCorreo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnBorrar))
                .addGap(18, 18, 18)
                .addComponent(btnDestruir)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jTabbedPane2)
                .addContainerGap())
        );

        jTabbedPane1.addTab("Personas", jPanel1);

        lblPlacas.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblPlacas.setText("Placas:");

        lblMarca.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblMarca.setText("Marca:");

        lblModelo.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblModelo.setText("Modelo:");

        btnCrearvehiculo.setText("Crear");
        btnCrearvehiculo.addActionListener(this::btnCrearvehiculoActionPerformed);

        btnGuardarVehiculo.setText("Guardar datos");
        btnGuardarVehiculo.addActionListener(this::btnGuardarVehiculoActionPerformed);

        btnBuscarVehiculo.setText("Buscar por placas");
        btnBuscarVehiculo.addActionListener(this::btnBuscarVehiculoActionPerformed);

        btnActualizarVehiculo.setText("Actualizar datos");
        btnActualizarVehiculo.addActionListener(this::btnActualizarVehiculoActionPerformed);

        btnBorrarVehiculo.setText("Borrar datos");
        btnBorrarVehiculo.addActionListener(this::btnBorrarVehiculoActionPerformed);

        btnDestruirVehiculo.setText("Destruir Objeto");
        btnDestruirVehiculo.addActionListener(this::btnDestruirVehiculoActionPerformed);

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(lblModelo, javax.swing.GroupLayout.DEFAULT_SIZE, 95, Short.MAX_VALUE)
                    .addComponent(lblMarca, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lblPlacas, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(18, 18, 18)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(txtMarca, javax.swing.GroupLayout.DEFAULT_SIZE, 111, Short.MAX_VALUE)
                    .addComponent(txtModelo)
                    .addComponent(txtPlacas))
                .addGap(62, 62, 62)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnActualizarVehiculo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnBorrarVehiculo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnDestruirVehiculo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnBuscarVehiculo)
                    .addComponent(btnGuardarVehiculo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnCrearvehiculo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(229, 229, 229))
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addGap(36, 36, 36)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblPlacas, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtPlacas, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnCrearvehiculo))
                .addGap(18, 18, 18)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblMarca, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtMarca, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnGuardarVehiculo))
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addGap(24, 24, 24)
                        .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblModelo, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtModelo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(btnBuscarVehiculo)))
                .addGap(18, 18, 18)
                .addComponent(btnActualizarVehiculo)
                .addGap(18, 18, 18)
                .addComponent(btnBorrarVehiculo)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 18, Short.MAX_VALUE)
                .addComponent(btnDestruirVehiculo))
        );

        jTabbedPane3.addTab("Vehiculo", jPanel9);

        lblCodigo.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblCodigo.setText("Codigo:");

        lblMax.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblMax.setText("Maximo de plazas:");

        lblEspaDis.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblEspaDis.setText("Espacios Disponibles:");

        lblNiveles.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblNiveles.setText("Niveles Estacionamiento:");

        btnCrearEstacionamiento.setText("Crear");
        btnCrearEstacionamiento.addActionListener(this::btnCrearEstacionamientoActionPerformed);

        btnGuardarEstacionamiento.setText("Guardar Datos");
        btnGuardarEstacionamiento.addActionListener(this::btnGuardarEstacionamientoActionPerformed);

        btnBuscarEstacionamiento.setText("Buscar por codigo");
        btnBuscarEstacionamiento.addActionListener(this::btnBuscarEstacionamientoActionPerformed);

        btnActualizarEstacionamiento.setText("Actualizar datos");
        btnActualizarEstacionamiento.addActionListener(this::btnActualizarEstacionamientoActionPerformed);

        btnBorrarEstacionamiento.setText("Borrar datos");
        btnBorrarEstacionamiento.addActionListener(this::btnBorrarEstacionamientoActionPerformed);

        btnDestruirEstacionamiento.setText("Destruir objeto");
        btnDestruirEstacionamiento.addActionListener(this::btnDestruirEstacionamientoActionPerformed);

        javax.swing.GroupLayout jPanel10Layout = new javax.swing.GroupLayout(jPanel10);
        jPanel10.setLayout(jPanel10Layout);
        jPanel10Layout.setHorizontalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(lblCodigo, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblMax)
                    .addComponent(lblEspaDis, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lblNiveles, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(31, 31, 31)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(txtCodigo, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtMax, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtEspaDis, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtNiveles, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(92, 92, 92)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnActualizarEstacionamiento, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnBorrarEstacionamiento, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnDestruirEstacionamiento, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnBuscarEstacionamiento)
                    .addComponent(btnGuardarEstacionamiento, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnCrearEstacionamiento, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(136, 136, 136))
        );
        jPanel10Layout.setVerticalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addGap(39, 39, 39)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblCodigo, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtCodigo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnCrearEstacionamiento))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblMax)
                    .addComponent(txtMax, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnGuardarEstacionamiento))
                .addGap(18, 18, 18)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblEspaDis, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtEspaDis, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnBuscarEstacionamiento))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblNiveles)
                    .addComponent(txtNiveles, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnActualizarEstacionamiento))
                .addGap(18, 18, 18)
                .addComponent(btnBorrarEstacionamiento)
                .addGap(18, 18, 18)
                .addComponent(btnDestruirEstacionamiento)
                .addContainerGap(25, Short.MAX_VALUE))
        );

        jTabbedPane3.addTab("Estacionamiento", jPanel10);

        lblNumL.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblNumL.setText("Numero de lugar:");

        lblEstado.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblEstado.setText("Estado");

        lblEspecialidad.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblEspecialidad.setText("Especialidad:");

        btnCrearEspacio.setText("Crear");
        btnCrearEspacio.addActionListener(this::btnCrearEspacioActionPerformed);

        btnGuardarEspacio.setText("Guardar datos");
        btnGuardarEspacio.addActionListener(this::btnGuardarEspacioActionPerformed);

        btnBuscarEspacio.setText("Buscar por lugar");
        btnBuscarEspacio.addActionListener(this::btnBuscarEspacioActionPerformed);

        btnActualizarEspacio.setText("Actualizar Datos");
        btnActualizarEspacio.addActionListener(this::btnActualizarEspacioActionPerformed);

        btnBorrarEspacio.setText("Borrar Datos");
        btnBorrarEspacio.addActionListener(this::btnBorrarEspacioActionPerformed);

        btnDestruirEspacio.setText("Destruir Objeto");
        btnDestruirEspacio.addActionListener(this::btnDestruirEspacioActionPerformed);

        javax.swing.GroupLayout jPanel11Layout = new javax.swing.GroupLayout(jPanel11);
        jPanel11.setLayout(jPanel11Layout);
        jPanel11Layout.setHorizontalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel11Layout.createSequentialGroup()
                        .addComponent(lblEspecialidad, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(txtEspecialidad, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel11Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(lblEstado, javax.swing.GroupLayout.PREFERRED_SIZE, 114, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblNumL, javax.swing.GroupLayout.PREFERRED_SIZE, 114, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(54, 54, 54)
                        .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(txtNumL, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtEstado, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(62, 62, 62)
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnDestruirEspacio)
                    .addComponent(btnBorrarEspacio)
                    .addComponent(btnActualizarEspacio)
                    .addComponent(btnCrearEspacio)
                    .addComponent(btnGuardarEspacio)
                    .addComponent(btnBuscarEspacio))
                .addContainerGap(208, Short.MAX_VALUE))
        );
        jPanel11Layout.setVerticalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addGap(48, 48, 48)
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblNumL)
                    .addComponent(txtNumL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnCrearEspacio))
                .addGap(18, 18, 18)
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblEstado)
                    .addComponent(txtEstado, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnGuardarEspacio))
                .addGap(18, 18, 18)
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblEspecialidad)
                    .addComponent(txtEspecialidad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnBuscarEspacio))
                .addGap(18, 18, 18)
                .addComponent(btnActualizarEspacio)
                .addGap(18, 18, 18)
                .addComponent(btnBorrarEspacio)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 18, Short.MAX_VALUE)
                .addComponent(btnDestruirEspacio)
                .addContainerGap())
        );

        jTabbedPane3.addTab("Espacio", jPanel11);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jTabbedPane3)
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(36, 36, 36)
                .addComponent(jTabbedPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 317, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(132, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Objetos", jPanel2);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jTabbedPane1))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jTabbedPane1))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtCorreoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtCorreoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtCorreoActionPerformed

    private void btnCrearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCrearActionPerformed
        if (per==null){
            String tipo = jTabbedPane2.getTitleAt(jTabbedPane2.getSelectedIndex());
            per = crearPersonaSegunTipo(tipo);
            JOptionPane.showMessageDialog(this, "Objeto " + tipo + " ha sido creado");
        }else if (per != null){
            JOptionPane.showMessageDialog(this,"El objeto Persona ya existe, primero debes destruirlo.");
        }
    }//GEN-LAST:event_btnCrearActionPerformed

    private void btnGuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuardarActionPerformed
        if(per == null){
            JOptionPane.showMessageDialog(this,"El objeto no ha sido creado");
        }else if(txtCURP.getText().isBlank()){
            JOptionPane.showMessageDialog(this,"El CURP es obligatorio para guardar los datos");
        }else {
            per.setCurp(txtCURP.getText());
            per.setApellidos(txtApellidos.getText());
            per.setNombre(txtNombre.getText());
            per.setTelefono(txtTelefono.getText());
            per.setCorreo(txtCorreo.getText());
            guardarDatosEspecificos(per);
            JOptionPane.showMessageDialog(this,"Datos de persona guardados");
            limpiarCamposPersona();
        }
    }//GEN-LAST:event_btnGuardarActionPerformed

    private void btnBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarActionPerformed
        if(per == null){
            JOptionPane.showMessageDialog(this,"El objeto no existe");
        }else
        if(Objects.equals(per.getCurp(), txtCURP.getText())){
            JOptionPane.showMessageDialog(this,per);
            txtCURP.setText(per.getCurp());
            txtApellidos.setText(per.getApellidos());
            txtNombre.setText(per.getNombre());
            txtTelefono.setText(per.getTelefono());
            txtCorreo.setText(per.getCorreo());
            cargarDatosEspecificos(per);
            seleccionarPestañaSegunTipo(per);
        }else{
            JOptionPane.showMessageDialog(this, "CURP no encontrada");
        }
    }//GEN-LAST:event_btnBuscarActionPerformed

    private void btnActualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnActualizarActionPerformed
        if(per == null){
            JOptionPane.showMessageDialog(this,"El objeto no ha sido actualizado");
        }else if(txtCURP.getText().isBlank()){
            JOptionPane.showMessageDialog(this,"El CURP es obligatorio para actualizar los datos");
        }else {
            per.setCurp(txtCURP.getText());
            per.setApellidos(txtApellidos.getText());
            per.setNombre(txtNombre.getText());
            per.setTelefono(txtTelefono.getText());
            per.setCorreo(txtCorreo.getText());
            guardarDatosEspecificos(per);
            JOptionPane.showMessageDialog(this,"Datos de persona actualizados");
            limpiarCamposPersona();
        }
    }//GEN-LAST:event_btnActualizarActionPerformed

    private void btnBorrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBorrarActionPerformed
        if(per == null){
            JOptionPane.showMessageDialog(this, "el objeto no existe");
        }else{
            per.setCurp("");
            per.setApellidos("");
            per.setNombre("");
            per.setTelefono("");
            per.setCorreo("");
            borrarDatosEspecificos(per);
            JOptionPane.showMessageDialog(this,"Datos de persona borrados");
            limpiarCamposPersona();
        }
    }//GEN-LAST:event_btnBorrarActionPerformed

    private void btnDestruirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDestruirActionPerformed
        if(per != null){
            per = null;
            JOptionPane.showMessageDialog(this,"Objeto persona ha sido destruido");
            limpiarCamposPersona();
        }else if(per == null){
            JOptionPane.showMessageDialog(this,"El objeto ya es nulo, no puede ser destruido");
        }
    }//GEN-LAST:event_btnDestruirActionPerformed

    private Persona crearPersonaSegunTipo(String tipo) {
        switch (tipo) {
            case "Gerente":
                return new Gerente();
            case "Cajero":
                return new Cajero();
            case "Valet":
                return new Valetp();
            case "Lava Autos":
                return new LavaAutos();
            case "Personal de Limpieza":
                return new PersonalL();
            case "Clientes":
                return new Cliente();
            default:
                return new Persona();
        }
    }

  
    private void guardarDatosEspecificos(Persona p) {
        if (p instanceof Gerente g) {
            g.setSucursal(txtSucursal.getText());
            try {
                g.setGastos(Double.parseDouble(txtGastos.getText()));
            } catch (NumberFormatException ex) {
                g.setGastos(0);
            }
        } else if (p instanceof Cajero c) {
            c.setFondoInicial(txtFondoIn.getText());
            c.setCorteF(txtCorteFin.getText());
            c.setTurnoC(txtTurnoC.getText());
            c.setCantidadTickets(txtTickets.getText());
        } else if (p instanceof Valetp v) {
            v.setAreaTrabajo(txtAreaT.getText());
            v.setTurno(txtTurno.getText());
        } else if (p instanceof LavaAutos l) {
            l.setPropinas(txtPropinas.getText());
            l.setAutosL(txtAutosL.getText());
        } else if (p instanceof PersonalL pl) {
            pl.setSueldo(txtSueldo.getText());
            pl.setNivelL(txtNivelEs.getText());
        } else if (p instanceof Cliente cli) {
            cli.setMetodoPago(txtMetodo.getText());
            cli.setHoraEntrada(txtHoraEn.getText());
            cli.setHoraSalida(txtHoraSa.getText());
        }
    }

    private void cargarDatosEspecificos(Persona p) {
        if (p instanceof Gerente g) {
            txtSucursal.setText(g.getSucursal());
            txtGastos.setText(String.valueOf(g.getGastos()));
        } else if (p instanceof Cajero c) {
            txtFondoIn.setText(c.getFondoInicial());
            txtCorteFin.setText(c.getCorteF());
            txtTurnoC.setText(c.getTurnoC());
            txtTickets.setText(c.getCantidadTickets());
        } else if (p instanceof Valetp v) {
            txtAreaT.setText(v.getAreaTrabajo());
            txtTurno.setText(v.getTurno());
        } else if (p instanceof LavaAutos l) {
            txtPropinas.setText(l.getPropinas());
            txtAutosL.setText(l.getAutosL());
        } else if (p instanceof PersonalL pl) {
            txtSueldo.setText(pl.getSueldo());
            txtNivelEs.setText(pl.getNivelL());
        } else if (p instanceof Cliente cli) {
            txtMetodo.setText(cli.getMetodoPago());
            txtHoraEn.setText(cli.getHoraEntrada());
            txtHoraSa.setText(cli.getHoraSalida());
        }
    }

    
    private void borrarDatosEspecificos(Persona p) {
        if (p instanceof Gerente g) {
            g.setSucursal("");
            g.setGastos(0);
        } else if (p instanceof Cajero c) {
            c.setFondoInicial("");
            c.setCorteF("");
            c.setTurnoC("");
            c.setCantidadTickets("");
        } else if (p instanceof Valetp v) {
            v.setAreaTrabajo("");
            v.setTurno("");
        } else if (p instanceof LavaAutos l) {
            l.setPropinas("");
            l.setAutosL("");
        } else if (p instanceof PersonalL pl) {
            pl.setSueldo("");
            pl.setNivelL("");
        } else if (p instanceof Cliente cli) {
            cli.setMetodoPago("");
            cli.setHoraEntrada("");
            cli.setHoraSalida("");
        }
    }

    
    private void limpiarCamposPersona() {
        txtCURP.setText("");
        txtApellidos.setText("");
        txtNombre.setText("");
        txtTelefono.setText("");
        txtCorreo.setText("");

        txtSucursal.setText("");
        txtGastos.setText("");
        txtFondoIn.setText("");
        txtCorteFin.setText("");
        txtTurnoC.setText("");
        txtTickets.setText("");
        txtAreaT.setText("");
        txtTurno.setText("");
        txtPropinas.setText("");
        txtAutosL.setText("");
        txtSueldo.setText("");
        txtNivelEs.setText("");
        txtMetodo.setText("");
        txtHoraEn.setText("");
        txtHoraSa.setText("");
    }

    
    private void seleccionarPestañaSegunTipo(Persona p) {
        String titulo;
        if (p instanceof Gerente) {
            titulo = "Gerente";
        } else if (p instanceof Cajero) {
            titulo = "Cajero";
        } else if (p instanceof Valetp) {
            titulo = "Valet";
        } else if (p instanceof LavaAutos) {
            titulo = "Lava Autos";
        } else if (p instanceof PersonalL) {
            titulo = "Personal de Limpieza";
        } else if (p instanceof Cliente) {
            titulo = "Clientes";
        } else {
            return;
        }
        for (int i = 0; i < jTabbedPane2.getTabCount(); i++) {
            if (jTabbedPane2.getTitleAt(i).equals(titulo)) {
                jTabbedPane2.setSelectedIndex(i);
                break;
            }
        }
    }

    private void txtCURPActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtCURPActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtCURPActionPerformed

    private void txtSucursalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtSucursalActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtSucursalActionPerformed

    private void txtGastosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtGastosActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtGastosActionPerformed

    private void txtFondoInActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtFondoInActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtFondoInActionPerformed

    private void txtCorteFinActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtCorteFinActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtCorteFinActionPerformed

    private void txtTurnoCActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtTurnoCActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtTurnoCActionPerformed

    private void txtTicketsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtTicketsActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtTicketsActionPerformed

    private void txtAreaTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtAreaTActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtAreaTActionPerformed

    private void txtTurnoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtTurnoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtTurnoActionPerformed

    private void txtPropinasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtPropinasActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtPropinasActionPerformed

    private void txtAutosLActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtAutosLActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtAutosLActionPerformed

    private void txtSueldoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtSueldoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtSueldoActionPerformed

    private void txtNivelEsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNivelEsActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtNivelEsActionPerformed

    private void txtHoraSaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtHoraSaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtHoraSaActionPerformed

    private void txtHoraEnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtHoraEnActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtHoraEnActionPerformed

    private void txtMetodoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtMetodoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtMetodoActionPerformed

    private void btnCrearvehiculoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCrearvehiculoActionPerformed
        if (vehiculo == null) {
            vehiculo = new Vehiculo();
            JOptionPane.showMessageDialog(this, "Objeto Vehículo ha sido creado.");
            limpiarCamposVehiculo();
        } else {
            JOptionPane.showMessageDialog(this, "El objeto Vehículo ya existe. Destrúyelo primero.");
        }
    }//GEN-LAST:event_btnCrearvehiculoActionPerformed

    private void btnGuardarVehiculoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuardarVehiculoActionPerformed
        if (vehiculo == null) {
            JOptionPane.showMessageDialog(this, "Primero debes crear el objeto Vehículo.");
            return;
        }
        if (txtPlacas.getText().isBlank()) {
            JOptionPane.showMessageDialog(this, "Las placas son obligatorias para guardar.");
            return;
        }
        vehiculo.setPlacasV(txtPlacas.getText());
        vehiculo.setMarcaV(txtMarca.getText());
        vehiculo.setModeloV(txtModelo.getText());
        JOptionPane.showMessageDialog(this, "Vehículo guardado con éxito.");
        limpiarCamposVehiculo();
    }//GEN-LAST:event_btnGuardarVehiculoActionPerformed

    private void btnBuscarVehiculoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarVehiculoActionPerformed
        if (vehiculo == null) {
            JOptionPane.showMessageDialog(this, "No hay ningún vehículo en el sistema.");
        } else if (txtPlacas.getText().equals(vehiculo.getPlacasV())) {
            txtMarca.setText(vehiculo.getMarcaV());
            txtModelo.setText(vehiculo.getModeloV());
            JOptionPane.showMessageDialog(this, "Vehículo encontrado y datos cargados.");
        } else {
            JOptionPane.showMessageDialog(this, "No se encontró un vehículo con las placas: " + txtPlacas.getText());
        }
    }//GEN-LAST:event_btnBuscarVehiculoActionPerformed

    private void btnActualizarVehiculoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnActualizarVehiculoActionPerformed
        if (vehiculo == null) {
            JOptionPane.showMessageDialog(this, "No hay objeto Vehículo para actualizar.");
        } else {
            vehiculo.setPlacasV(txtPlacas.getText());
            vehiculo.setMarcaV(txtMarca.getText());
            vehiculo.setModeloV(txtModelo.getText());
            JOptionPane.showMessageDialog(this, "Datos del vehículo actualizados.");
            limpiarCamposVehiculo();
        }
    }//GEN-LAST:event_btnActualizarVehiculoActionPerformed

    private void btnBorrarVehiculoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBorrarVehiculoActionPerformed
        if (vehiculo != null) {
            vehiculo.setPlacasV("");
            vehiculo.setMarcaV("");
            vehiculo.setModeloV("");
            JOptionPane.showMessageDialog(this, "Datos del vehículo borrados internamente.");
            limpiarCamposVehiculo();
        } else {
            JOptionPane.showMessageDialog(this, "El objeto no existe.");
        }
    }//GEN-LAST:event_btnBorrarVehiculoActionPerformed

    private void btnDestruirVehiculoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDestruirVehiculoActionPerformed
        if (vehiculo != null) {
            vehiculo = null;
            JOptionPane.showMessageDialog(this, "Objeto Vehículo destruido en memoria.");
            limpiarCamposVehiculo();
        }
    }//GEN-LAST:event_btnDestruirVehiculoActionPerformed

    private void btnCrearEstacionamientoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCrearEstacionamientoActionPerformed
        if (estacionamiento == null) {
            estacionamiento = new Estacionamiento();
            JOptionPane.showMessageDialog(this, "Objeto Estacionamiento ha sido creado.");
            limpiarCamposEstacionamiento();
        } else {
            JOptionPane.showMessageDialog(this, "El objeto Estacionamiento ya existe.");
        }
    }//GEN-LAST:event_btnCrearEstacionamientoActionPerformed

    private void btnGuardarEstacionamientoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuardarEstacionamientoActionPerformed
        if (estacionamiento == null) {
            JOptionPane.showMessageDialog(this, "Primero crea el objeto Estacionamiento.");
            return;
        }
        if (txtCodigo.getText().isBlank()) {
            JOptionPane.showMessageDialog(this, "El código es obligatorio.");
            return;
        }
        estacionamiento.setCodigo(txtCodigo.getText());
        estacionamiento.setMaximoPlazas(txtMax.getText());
        estacionamiento.setEspaciosDis(txtEspaDis.getText());
        estacionamiento.setNiveles(txtNiveles.getText());
        JOptionPane.showMessageDialog(this, "Estacionamiento guardado con éxito.");
        limpiarCamposEstacionamiento();
    }//GEN-LAST:event_btnGuardarEstacionamientoActionPerformed

    private void btnBuscarEstacionamientoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarEstacionamientoActionPerformed
        if (estacionamiento == null) {
            JOptionPane.showMessageDialog(this, "No hay estacionamiento registrado.");
        } else if (txtCodigo.getText().equals(estacionamiento.getCodigo())) {
            txtMax.setText(estacionamiento.getMaximoPlazas());
            txtEspaDis.setText(estacionamiento.getEspaciosDis());
            txtNiveles.setText(estacionamiento.getNiveles());
            JOptionPane.showMessageDialog(this, "Estacionamiento encontrado.");
        } else {
            JOptionPane.showMessageDialog(this, "Código no encontrado.");
        }
    }//GEN-LAST:event_btnBuscarEstacionamientoActionPerformed

    private void btnActualizarEstacionamientoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnActualizarEstacionamientoActionPerformed
        if (estacionamiento != null) {
            estacionamiento.setCodigo(txtCodigo.getText());
            estacionamiento.setMaximoPlazas(txtMax.getText());
            estacionamiento.setEspaciosDis(txtEspaDis.getText());
            estacionamiento.setNiveles(txtNiveles.getText());
            JOptionPane.showMessageDialog(this, "Estacionamiento actualizado.");
            limpiarCamposEstacionamiento();
        }
    }//GEN-LAST:event_btnActualizarEstacionamientoActionPerformed

    private void btnBorrarEstacionamientoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBorrarEstacionamientoActionPerformed
        if (estacionamiento != null) {
            estacionamiento.setCodigo("");
            estacionamiento.setMaximoPlazas("");
            estacionamiento.setEspaciosDis("");
            estacionamiento.setNiveles("");
            JOptionPane.showMessageDialog(this, "Datos borrados.");
            limpiarCamposEstacionamiento();
        }
    }//GEN-LAST:event_btnBorrarEstacionamientoActionPerformed

    private void btnDestruirEstacionamientoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDestruirEstacionamientoActionPerformed
        estacionamiento = null;
        JOptionPane.showMessageDialog(this, "Objeto Estacionamiento destruido.");
        limpiarCamposEstacionamiento();
    }//GEN-LAST:event_btnDestruirEstacionamientoActionPerformed

    private void btnActualizarEspacioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnActualizarEspacioActionPerformed
        if (espacio != null) {
            espacio.setNumeroL(txtNumL.getText());
            espacio.setEstado(txtEstado.getText());
            espacio.setEspecial(txtEspecialidad.getText());
            JOptionPane.showMessageDialog(this, "Datos actualizados.");
            limpiarCamposEspacio();
        }
    }//GEN-LAST:event_btnActualizarEspacioActionPerformed

    private void btnCrearEspacioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCrearEspacioActionPerformed
        if (espacio == null) {
            espacio = new Espacio();
            JOptionPane.showMessageDialog(this, "Objeto Espacio creado.");
            limpiarCamposEspacio();
        } else {
            JOptionPane.showMessageDialog(this, "El objeto Espacio ya existe.");
        }
    }//GEN-LAST:event_btnCrearEspacioActionPerformed

    private void btnGuardarEspacioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuardarEspacioActionPerformed
        if (espacio == null) {
            JOptionPane.showMessageDialog(this, "Crea el objeto primero.");
            return;
        }
        if (txtNumL.getText().isBlank()) {
            JOptionPane.showMessageDialog(this, "El número de lugar es obligatorio.");
            return;
        }
        espacio.setNumeroL(txtNumL.getText());
        espacio.setEstado(txtEstado.getText());
        espacio.setEspecial(txtEspecialidad.getText());
        JOptionPane.showMessageDialog(this, "Espacio guardado con éxito.");
        limpiarCamposEspacio();
    }//GEN-LAST:event_btnGuardarEspacioActionPerformed

    private void btnBuscarEspacioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarEspacioActionPerformed
        if (espacio == null) {
            JOptionPane.showMessageDialog(this, "No hay espacio registrado.");
        } else if (txtNumL.getText().equals(espacio.getNumeroL())) {
            txtEstado.setText(espacio.getEstado());
            txtEspecialidad.setText(espacio.getEspecial());
            JOptionPane.showMessageDialog(this, "Espacio encontrado.");
        } else {
            JOptionPane.showMessageDialog(this, "Lugar no encontrado.");
        }
    }//GEN-LAST:event_btnBuscarEspacioActionPerformed

    private void btnBorrarEspacioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBorrarEspacioActionPerformed
        if (espacio != null) {
            espacio.setNumeroL("");
            espacio.setEstado("");
            espacio.setEspecial("");
            JOptionPane.showMessageDialog(this, "Datos borrados.");
            limpiarCamposEspacio();
        }
    }//GEN-LAST:event_btnBorrarEspacioActionPerformed

    private void btnDestruirEspacioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDestruirEspacioActionPerformed
        espacio = null;
        JOptionPane.showMessageDialog(this, "Objeto Espacio destruido.");
        limpiarCamposEspacio();
    }//GEN-LAST:event_btnDestruirEspacioActionPerformed
private void limpiarCamposEspacio() {
        txtNumL.setText("");
        txtEstado.setText("");
        txtEspecialidad.setText("");
    }
private void limpiarCamposEstacionamiento() {
        txtCodigo.setText("");
        txtMax.setText("");
        txtEspaDis.setText("");
        txtNiveles.setText("");
    }
private void limpiarCamposVehiculo() {
        txtPlacas.setText("");
        txtMarca.setText("");
        txtModelo.setText("");
    }
    private void txtPlacasActionPerformed(java.awt.event.ActionEvent evt) {
        // TODO add your handling code here:
    }

    private void txtMarcaActionPerformed(java.awt.event.ActionEvent evt) {
        // TODO add your handling code here:
    }

    private void txtModeloActionPerformed(java.awt.event.ActionEvent evt) {
   
    }

    private void txtCodigoActionPerformed(java.awt.event.ActionEvent evt) {
        // TODO add your handling code here:
    }

    private void txtMaxActionPerformed(java.awt.event.ActionEvent evt) {
        // TODO add your handling code here:
    }

    private void txtEspaDisActionPerformed(java.awt.event.ActionEvent evt) {
        // TODO add your handling code here:
    }

    private void txtNivelesActionPerformed(java.awt.event.ActionEvent evt) {
        
    }

    private void txtNumLActionPerformed(java.awt.event.ActionEvent evt) {
        // TODO add your handling code here:
    }

    private void txtEstadoActionPerformed(java.awt.event.ActionEvent evt) {
        // TODO add your handling code here:
    }

    private void txtEspecialidadActionPerformed(java.awt.event.ActionEvent evt) {
        
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new GUIPersonas().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnActualizar;
    private javax.swing.JButton btnActualizarEspacio;
    private javax.swing.JButton btnActualizarEstacionamiento;
    private javax.swing.JButton btnActualizarVehiculo;
    private javax.swing.JButton btnBorrar;
    private javax.swing.JButton btnBorrarEspacio;
    private javax.swing.JButton btnBorrarEstacionamiento;
    private javax.swing.JButton btnBorrarVehiculo;
    private javax.swing.JButton btnBuscar;
    private javax.swing.JButton btnBuscarEspacio;
    private javax.swing.JButton btnBuscarEstacionamiento;
    private javax.swing.JButton btnBuscarVehiculo;
    private javax.swing.JButton btnCrear;
    private javax.swing.JButton btnCrearEspacio;
    private javax.swing.JButton btnCrearEstacionamiento;
    private javax.swing.JButton btnCrearvehiculo;
    private javax.swing.JButton btnDestruir;
    private javax.swing.JButton btnDestruirEspacio;
    private javax.swing.JButton btnDestruirEstacionamiento;
    private javax.swing.JButton btnDestruirVehiculo;
    private javax.swing.JButton btnGuardar;
    private javax.swing.JButton btnGuardarEspacio;
    private javax.swing.JButton btnGuardarEstacionamiento;
    private javax.swing.JButton btnGuardarVehiculo;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JTabbedPane jTabbedPane2;
    private javax.swing.JTabbedPane jTabbedPane3;
    private javax.swing.JLabel lblApellidos;
    private javax.swing.JLabel lblAreaT;
    private javax.swing.JLabel lblAutosL;
    private javax.swing.JLabel lblCURP;
    private javax.swing.JLabel lblCodigo;
    private javax.swing.JLabel lblCorreo;
    private javax.swing.JLabel lblCorteFin;
    private javax.swing.JLabel lblEspaDis;
    private javax.swing.JLabel lblEspecialidad;
    private javax.swing.JLabel lblEstado;
    private javax.swing.JLabel lblFondoIn;
    private javax.swing.JLabel lblGastos;
    private javax.swing.JLabel lblHoraEn;
    private javax.swing.JLabel lblHoraSa;
    private javax.swing.JLabel lblMarca;
    private javax.swing.JLabel lblMax;
    private javax.swing.JLabel lblMetodo;
    private javax.swing.JLabel lblModelo;
    private javax.swing.JLabel lblNivelEs;
    private javax.swing.JLabel lblNiveles;
    private javax.swing.JLabel lblNombre;
    private javax.swing.JLabel lblNumL;
    private javax.swing.JLabel lblPlacas;
    private javax.swing.JLabel lblPropinas;
    private javax.swing.JLabel lblSucursal;
    private javax.swing.JLabel lblSueldo;
    private javax.swing.JLabel lblTelefono;
    private javax.swing.JLabel lblTickets;
    private javax.swing.JLabel lblTurno;
    private javax.swing.JLabel lblTurnoC;
    private javax.swing.JTextField txtApellidos;
    private javax.swing.JTextField txtAreaT;
    private javax.swing.JTextField txtAutosL;
    private javax.swing.JTextField txtCURP;
    private javax.swing.JTextField txtCodigo;
    private javax.swing.JTextField txtCorreo;
    private javax.swing.JTextField txtCorteFin;
    private javax.swing.JTextField txtEspaDis;
    private javax.swing.JTextField txtEspecialidad;
    private javax.swing.JTextField txtEstado;
    private javax.swing.JTextField txtFondoIn;
    private javax.swing.JTextField txtGastos;
    private javax.swing.JTextField txtHoraEn;
    private javax.swing.JTextField txtHoraSa;
    private javax.swing.JTextField txtMarca;
    private javax.swing.JTextField txtMax;
    private javax.swing.JTextField txtMetodo;
    private javax.swing.JTextField txtModelo;
    private javax.swing.JTextField txtNivelEs;
    private javax.swing.JTextField txtNiveles;
    private javax.swing.JTextField txtNombre;
    private javax.swing.JTextField txtNumL;
    private javax.swing.JTextField txtPlacas;
    private javax.swing.JTextField txtPropinas;
    private javax.swing.JTextField txtSucursal;
    private javax.swing.JTextField txtSueldo;
    private javax.swing.JTextField txtTelefono;
    private javax.swing.JTextField txtTickets;
    private javax.swing.JTextField txtTurno;
    private javax.swing.JTextField txtTurnoC;
    // End of variables declaration//GEN-END:variables
}
